# Deploy STYLE Global Sales OS to Streamlit

## Recommended public URL

**Product name:** STYLE Global Sales OS

**Preferred URL slug:**

`style-global-sales-os`

Expected URL if the slug is available:

`https://style-global-sales-os.streamlit.app/`

---

## Files Streamlit needs

The deployment package already includes:

- `app.py`
- `requirements.txt`
- `runtime.txt`
- `.streamlit/config.toml`
- `core/config.py`
- `core/database.py`
- `core/scoring.py`
- `core/styles.py`
- `core/seed.py`
- `core/email_engine.py`
- `README.md`
- `.env.example`
- `.gitignore`

The app uses SQLite and creates the database automatically on first run.

---

## GitHub upload

Create a GitHub repository named:

`style-global-sales-os`

Upload **the contents of the extracted ZIP**, not the ZIP itself.

The root of the GitHub repo must look like:

```text
style-global-sales-os/
├── app.py
├── requirements.txt
├── runtime.txt
├── README.md
├── .gitignore
├── .env.example
├── .streamlit/
│   └── config.toml
└── core/
    ├── config.py
    ├── database.py
    ├── scoring.py
    ├── styles.py
    ├── seed.py
    └── email_engine.py
```

---

## Streamlit Community Cloud

1. Sign in to Streamlit Community Cloud using GitHub.
2. Click **Create app** / **New app**.
3. Select the repository:
   `style-global-sales-os`
4. Branch:
   `main`
5. Main file path:
   `app.py`
6. Choose the app URL:
   `style-global-sales-os`
7. Deploy.

---

## If Streamlit asks for Python

Use Python 3.11.

The project includes:

`runtime.txt`

with:

`python-3.11`

---

## Optional Brevo integration

Do NOT put a Brevo API key inside source code.

In Streamlit:

App Settings → Secrets

Add:

```toml
BREVO_API_KEY = "YOUR_KEY_HERE"
```

The current app works without this key.
It is ready for a later Brevo API integration.

---

## First production action after deployment

Replace the DEMO accounts and strategic model values with:

1. verified target buyers
2. verified decision makers
3. actual RFQs
4. current quotations
5. real market-import data
6. freight / tariff / customs data verified for the exact shipment
7. Style's real commercial margins and conversion rates

This converts the application from a strategic prototype into an operating sales system.
