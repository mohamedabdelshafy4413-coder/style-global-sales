
def build_email(language, persona, company, contact, product):
    company = company or "[Company]"
    contact = contact or "[Name]"
    product = product or "Egyptian marble & granite"

    value = {
        "Importer":"stable container supply, availability and repeatable quality",
        "Distributor":"repeat supply, portfolio fit and dependable replenishment",
        "Fabricator":"consistent material, finish control and workable formats",
        "Contractor":"project quantities, submittals, schedule and packing reliability",
        "Developer":"project specification, value engineering and dependable delivery",
        "Architect":"samples, technical documentation, finishes and specification support",
        "Procurement":"clear commercial terms, documentation, lead time and risk reduction",
    }.get(persona, "reliable export supply")

    if language == "Arabic":
        subject = f"{contact} — توريد حجر مصري مناسب لـ {company}"
        body = f"""أستاذ/ة {contact}،

أتواصل لأن نشاط {company} قريب من نوع المشترين الذين نخدمهم في التوريد الدولي للحجر الطبيعي.

Style for Marble & Granite تعمل في الرخام والجرانيت المصري، وبالنسبة لاحتياجكم أرى أن نقطة البداية الأقوى هي: {product}.

بدل إرسال كتالوج عام، لو تبعت لي 4 بيانات فقط — الخامة، المقاس/السُمك، الكمية، وميناء الوصول — أقدر أجهز لك عرض موجه للشحنة يركز على {value}.

هل مشترياتكم الحالية للمخزون/التوزيع أم لمشروع محدد؟

تحياتي،
[Name]
Style for Marble & Granite"""
    elif language == "French":
        subject = f"{contact} — option pierre égyptienne pour {company}"
        body = f"""Bonjour {contact},

Je vous contacte car l’activité de {company} correspond au type d’acheteurs que nous ciblons pour l’export de pierre naturelle égyptienne.

Pour commencer, je vous proposerais : {product}.

Au lieu d’un catalogue générique, si vous me partagez matériau + dimensions/épaisseur + quantité + port de destination, nous pouvons préparer une proposition centrée sur {value}.

Achetez-vous actuellement pour stock/distribution ou pour un projet précis ?

Cordialement,
[Name]
Style for Marble & Granite"""
    else:
        subject = f"{contact} — Egyptian stone supply option for {company}"
        body = f"""Hi {contact},

I’m reaching out because {company} looks relevant to the type of international buyers we support with Egyptian natural stone.

For your market, I would start with: {product}.

Rather than send a generic catalogue, if you share just four details — material, size/thickness, quantity and destination port — we can prepare a shipment-oriented offer focused on {value}.

Are you currently buying for stock/distribution or for a specific project?

Best regards,
[Name]
Style for Marble & Granite"""
    return subject, body
