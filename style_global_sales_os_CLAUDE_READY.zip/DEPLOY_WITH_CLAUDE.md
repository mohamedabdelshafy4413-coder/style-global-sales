# How to build and deploy this project with Claude Code

## Fastest workflow

### 1. Extract this project
Unzip the package into a folder named:

`style-global-sales-os`

### 2. Put the folder on GitHub
Create a new GitHub repository:

`style-global-sales-os`

Upload the **contents** of the extracted folder.

Do not upload only the ZIP.

### 3. Open the project with Claude Code
Use Claude Code in a terminal or supported IDE and open the repository folder.

Claude Code will automatically read `CLAUDE.md`.

### 4. Give Claude this first command

```text
Take ownership of this repository.

Read CLAUDE.md and inspect the entire codebase.

Install dependencies, run `streamlit run app.py`, fix every error you find, and continue until the app is stable.

Do not just explain fixes — edit the files directly.

After the app is stable, improve the Arabic RTL UX, Golden 5, Golden Accounts, 72-Hour Opportunities, RFQ flow, Sales Pipeline and Email Campaign Center.

Keep all demo data explicitly marked DEMO.

Then perform a full deployment QA audit and commit the final changes.
```

### 5. Give Claude this second command

```text
Now audit STYLE Global Sales OS as a senior global B2B sales systems architect.

Remove anything that feels like a generic dashboard.

Every module must help management answer:
- Where should we sell?
- Who should we sell to?
- What should we sell?
- Why would the buyer buy?
- What should sales do next?
- Which account can become a large repeat buyer?

Improve the product directly, run it again, and fix any issues.
```

### 6. Deploy on Streamlit Community Cloud

In Streamlit Community Cloud:

- Repository: `style-global-sales-os`
- Branch: `main`
- Main file: `app.py`
- Preferred app URL: `style-global-sales-os`

If available, the public URL will be:

`https://style-global-sales-os.streamlit.app/`

### 7. Add secrets later

Never put API keys inside the source.

Use Streamlit:
App Settings → Secrets

Example:

```toml
BREVO_API_KEY = "YOUR_KEY"
```

## If Claude cannot deploy Streamlit itself
That is normal.

Claude should make the repository deployment-ready.
You only need to open Streamlit Cloud, select the GitHub repo, choose `app.py`, and click Deploy.
