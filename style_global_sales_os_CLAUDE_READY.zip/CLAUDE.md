# STYLE Global Sales OS — Claude Code Instructions

You are the senior engineer and product owner for this repository.

## Product
STYLE Global Sales OS is an Arabic-first Streamlit B2B export and sales operating system for Style for Marble & Granite.

## Primary commercial objective
Optimize the product around:

Target Account
→ Decision Maker
→ Positive Reply
→ Qualified Conversation
→ RFQ
→ Quote
→ Negotiation
→ Trial Order
→ Container Order
→ Repeat Shipment
→ Strategic Account

Do not optimize for vanity metrics.

## Technical stack
- Python
- Streamlit
- Pandas
- Plotly
- SQLite
- openpyxl
- requests

## Main entrypoint
`app.py`

## Required behavior
1. Inspect the repository before editing.
2. Install dependencies from `requirements.txt`.
3. Run:
   `streamlit run app.py`
4. Fix all runtime/import/SQLite/RTL/UI/path/session-state errors directly.
5. Re-run after each major change.
6. Keep Arabic RTL as the primary interface.
7. Never hardcode secrets.
8. Keep demo data clearly marked DEMO.
9. Do not fabricate real buyers, customs rules, tariff data, or verified market facts.
10. Keep the app Streamlit Community Cloud compatible.

## Deployment target
Preferred Streamlit URL slug:
`style-global-sales-os`

Preferred URL if available:
`https://style-global-sales-os.streamlit.app/`

Do not claim the URL exists until deployment succeeds.

## Product priorities
P0:
- App launches successfully
- Executive Command Center
- Top 10 Markets
- Golden 5
- Country Intelligence
- Golden Accounts
- 72-Hour Opportunities
- Pipeline
- RFQ Manager
- Email Campaign Builder
- CSV/Excel import/export

P1:
- Next Best Action
- Better validation
- Better empty states
- Role-based views
- Brevo integration
- Research source tracking
- Alerts

## QA checklist before finalizing
- `streamlit run app.py` works
- no import errors
- no missing files
- SQLite initializes
- Arabic RTL renders
- navigation works
- charts render
- data_editor changes persist
- CSV import/export works
- Excel import/export works
- market scoring works
- account scoring works
- RFQ manager works
- email generator works
- no secrets exposed
- requirements are complete
- Streamlit config is valid

When asked to improve the app, make the changes directly rather than only describing them.
