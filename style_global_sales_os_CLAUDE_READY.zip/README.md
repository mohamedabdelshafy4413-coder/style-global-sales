
# STYLE Global Sales OS

Arabic-first Streamlit application for international B2B export sales of Style for Marble & Granite.

## Run locally

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Install:

```bash
pip install -r requirements.txt
```

Run:

```bash
streamlit run app.py
```

Then open the local URL shown by Streamlit.

## Deploy to Streamlit Community Cloud

1. Create a GitHub repository named `style-global-sales-os`.
2. Upload all project files.
3. Open Streamlit Community Cloud.
4. Click **Create app** / **New app**.
5. Select the GitHub repository.
6. Branch: `main`
7. Main file: `app.py`
8. Deploy.
9. Choose the public URL if the desired subdomain is available.

## Important

The seeded markets and accounts are explicitly DEMO / strategic model data.
Replace them with verified trade, customs, buyer, RFQ, freight and sales data before relying on the system for commercial decisions.

Never place API keys in source code.
Use Streamlit Secrets for Brevo or future integrations.
